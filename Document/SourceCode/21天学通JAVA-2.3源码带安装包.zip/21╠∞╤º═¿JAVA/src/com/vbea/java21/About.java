package com.vbea.java21;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Button;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.DialogInterface;
import android.view.View;
import android.view.View.OnClickListener;

public class About extends Activity
{
	SharedPreferences spt;
	TextView txt_Invate,txt_IDate,txt_Iver,txt_Iname;
	Button btn_active;
	Editor sh_edt;
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.about);
		
		spt = getSharedPreferences("java21", Context.MODE_PRIVATE);
		sh_edt = spt.edit();
		txt_Invate = (TextView) findViewById(R.id.txt_invate);
		txt_IDate = (TextView) findViewById(R.id.txt_iTime);
		txt_Iver = (TextView) findViewById(R.id.txt_iVersion);
		txt_Iname = (TextView) findViewById(R.id.abt_appName);
		btn_active = (Button) findViewById(R.id.abt_btnUnact);
		isActive();
		btn_active.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				new AlertDialog.Builder(About.this)
				.setTitle("提示")
				.setMessage("确认要取消激活该软件？")
				.setPositiveButton("确定", new DialogInterface.OnClickListener()
				{
					public void onClick(DialogInterface dialog, int swich)
					{
						sh_edt.putString("date","未激活");
						sh_edt.putString("psd","未激活");
						sh_edt.putBoolean("isActive", false);
						sh_edt.putBoolean("iVer",false);
						sh_edt.putBoolean("iHer",false);
						sh_edt.putInt("chapter",0);
						sh_edt.commit();
						isActive();
					}
				})
				.setNegativeButton("取消",null)
				.show();
			}
		});
	}
	private void isActive()
	{
		//TextView txt_Invate = (TextView) findViewById(R.id.txt_invate);
		//TextView txt_IDate = (TextView) findViewById(R.id.txt_iTime);
		//SharedPreferences spt = getSharedPreferences("java21", Context.MODE_PRIVATE);
		String date = spt.getString("date","未激活");
		boolean isa = spt.getBoolean("isActive",false);
		boolean ive = spt.getBoolean("iVer", false);
		boolean ihe = spt.getBoolean("iHer", false);
		String args[] = new String[3];
		try
		{
			args = date.split("-");
			txt_IDate.setText(args[0]+"年"+args[1]+"月"+args[2]+"日");
			btn_active.setVisibility(View.VISIBLE);
		}
		catch (Exception e)
		{
			txt_IDate.setText(date);
			btn_active.setVisibility(View.GONE);
		}
		txt_Invate.setText(spt.getString("psd", "未激活"));
		if (isa)
		{
			if (!ihe)
			{
				if (ive)
				{
					txt_Iver.setText("完整版");
					txt_Iname.setText("21天学通Java(完整版)");
				}
				else
				{
					txt_Iver.setText("标准版");
					txt_Iname.setText("21天学通Java(标准版)");
				}
			}
			else
			{
				txt_Iver.setText("定制版");
				txt_Iname.setText("21天学通Java(Bxa版)");
			}
		}
		else
		{
			txt_Iver.setText("未获取");
		}
	}

	@Override
	protected void onPause()
	{
		// TODO: Implement this method
		super.onPause();
	}

	@Override
	protected void onResume()
	{
		// TODO: Implement this method
		super.onResume();
		isActive();
	}

	@Override
	protected void onDestroy()
	{
		// TODO: Implement this method
		super.onDestroy();
	}
}
