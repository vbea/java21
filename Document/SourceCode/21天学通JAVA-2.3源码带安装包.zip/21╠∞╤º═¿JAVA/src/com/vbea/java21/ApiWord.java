package com.vbea.java21;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.PopupWindow;
import android.widget.LinearLayout.LayoutParams;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.graphics.drawable.BitmapDrawable;

public class ApiWord extends Activity
{
	private WebView myweb;
	private ProgressBar proGro;
	private PopupWindow popwin;
	private Button btn_goto;
	private Button btn_goback;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.apiword);
		
		ImageButton btn_opt = (ImageButton) findViewById(R.id.btn_option);
		proGro = (ProgressBar) findViewById(R.id.apiProgress);
		myweb = (WebView) findViewById(R.id.WebViewApi);
		myweb.getSettings().setJavaScriptEnabled(true);
		myweb.loadUrl("http://www.vbes.tk/JavaAPI/index.html");
		/*myweb.setFocusable(true);
		myweb.setFocusableInTouchMode(true);
		myweb.requestFocus();*/
		myweb.setWebViewClient(new WebViewClient());
		btn_opt.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				if (popwin.isShowing())
				{
					popwin.dismiss();
				}
				else
				{
					popwin.showAsDropDown(findViewById(R.id.btn_option));
					btnEnable();
				}
			}
		});
		myweb.setWebChromeClient(new WebChromeClient()
		{
			@Override
			public void onProgressChanged(WebView view, int newProgress)
			{
				if (newProgress <= 50)
					proGro.setSecondaryProgress(newProgress * 2);
				proGro.setProgress(newProgress);
				proGro.setVisibility(newProgress == 100 ? View.GONE : View.VISIBLE);
			}
		});
		
		View popview = getLayoutInflater().inflate(R.layout.apimenu, null);
		popwin = new PopupWindow(popview, LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, false);
		popwin.setBackgroundDrawable(new BitmapDrawable());
		popwin.setOutsideTouchable(true);
		popwin.setFocusable(true);
		
		Button btn_home = (Button) popview.findViewById(R.id.pop_homepage);
		Button btn_back = (Button) popview.findViewById(R.id.pop_back);
		Button btn_refresh = (Button) popview.findViewById(R.id.pop_refresh);
		btn_goto = (Button) popview.findViewById(R.id.pop_goto);
		btn_goback = (Button) popview.findViewById(R.id.pop_goback);
		
		btn_home.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				myweb.loadUrl("http://www.vbes.tk/JavaAPI/index.html");
				popwin.dismiss();
			}
		});
		
		btn_back.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				finish();
			}
		});
		
		btn_refresh.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				myweb.reload();
				popwin.dismiss();
			}
		});

		btn_goto.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				myweb.goForward();
				popwin.dismiss();
			}
		});
		
		btn_goback.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				myweb.goBack();
				popwin.dismiss();
			}
		});
	}
	public void btnEnable()
	{
		if(myweb.canGoBack())
		{
			btn_goback.setEnabled(true);
			btn_goback.setTextColor(getResources().getColorStateList(R.color.btn_text_colors));
		}
		else
		{
			btn_goback.setEnabled(false);
			btn_goback.setTextColor(getResources().getColor(R.color.grey2));
		}
		
		if (myweb.canGoForward())
		{
			btn_goto.setEnabled(true);
			btn_goto.setTextColor(getResources().getColorStateList(R.color.btn_text_colors));
		}
		else
		{
			btn_goto.setEnabled(false);
			btn_goto.setTextColor(getResources().getColor(R.color.grey2));
		}
	}
	@Override
    //设置回退 
    //覆盖Activity类的onKeyDown(int keyCoder,KeyEvent event)方法 
    public boolean onKeyDown(int keyCode, KeyEvent event)
	{ 
        if ((keyCode == KeyEvent.KEYCODE_BACK) && myweb.canGoBack())
		{ 
            myweb.goBack(); //goBack()表示返回WebView的上一页面 
            return true; 
        } 
        return super.onKeyDown(keyCode, event);
	}
}
