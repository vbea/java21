package com.vbea.java21;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.widget.TextView;

public class Audition extends Activity
{
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.webview);
		
		TextView title = (TextView) findViewById(R.id.webTitle);
		WebView webview = (WebView) findViewById(R.id.webview1);
		
		title.setText("Java面试题");
		webview.loadUrl("file:///android_asset/java/java_audition.htm");
	}
}
