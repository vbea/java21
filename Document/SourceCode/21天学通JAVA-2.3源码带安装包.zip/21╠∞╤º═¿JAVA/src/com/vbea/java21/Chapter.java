package com.vbea.java21;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.view.View;
import android.content.Intent;
import java.lang.Class;
import java.util.List;
import android.widget.*;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.view.*;

import com.qq.e.ads.AdRequest;
import com.qq.e.ads.AdServiceManager;
import com.qq.e.ads.AdSize;
import com.qq.e.ads.AdView;
import com.qq.e.ads.AdListener;
import android.util.*;

public class Chapter extends Activity
{
	private Button [] btn_c;
	private Class [] cls;
	private SharedPreferences spf;
	private Editor edt;
	private int thisCap;
	//private List<Class> cls;
	@Override
	public void onCreate(Bundle savedIntanceState)
	{
		super.onCreate(savedIntanceState);
		setContentView(R.layout.chapter);
		//onBanner();
		spf = getSharedPreferences("java21", Context.MODE_PRIVATE);
		thisCap = spf.getInt("chapter",0);
		btn_c = new Button[23];
		//按钮数组关联
		btn_c[0] = (Button) findViewById(R.id.btn_c01);
		btn_c[1] = (Button) findViewById(R.id.btn_c02);
		btn_c[2] = (Button) findViewById(R.id.btn_c03);
		btn_c[3] = (Button) findViewById(R.id.btn_c04);
		btn_c[4] = (Button) findViewById(R.id.btn_c05);
		btn_c[5] = (Button) findViewById(R.id.btn_c06);
		btn_c[6] = (Button) findViewById(R.id.btn_c07);
		btn_c[7] = (Button) findViewById(R.id.btn_c08);
		btn_c[8] = (Button) findViewById(R.id.btn_c09);
		btn_c[9] = (Button) findViewById(R.id.btn_c10);
		btn_c[10] = (Button) findViewById(R.id.btn_c11);
		btn_c[11] = (Button) findViewById(R.id.btn_c12);
		btn_c[12] = (Button) findViewById(R.id.btn_c13);
		btn_c[13] = (Button) findViewById(R.id.btn_c14);
		btn_c[14] = (Button) findViewById(R.id.btn_c15);
		btn_c[15] = (Button) findViewById(R.id.btn_c16);
		btn_c[16] = (Button) findViewById(R.id.btn_c17);
		btn_c[17] = (Button) findViewById(R.id.btn_c18);
		btn_c[18] = (Button) findViewById(R.id.btn_c19);
		btn_c[19] = (Button) findViewById(R.id.btn_c20);
		btn_c[20] = (Button) findViewById(R.id.btn_c21);
		btn_c[21] = (Button) findViewById(R.id.btn_c22);
		btn_c[22] = (Button) findViewById(R.id.btn_c23);
		//Activity数组关联
		cls = new Class[23];
		cls[0] = Chapter01.class;
		cls[1] = Chapter02.class;
		cls[2] = Chapter03.class;
		cls[3] = Chapter04.class;
		cls[4] = Chapter05.class;
		cls[5] = Chapter06.class;
		cls[6] = Chapter07.class;
		cls[7] = Chapter08.class;
		cls[8] = Chapter09.class;
		cls[9] = Chapter10.class;
		cls[10] = Chapter11.class;
		cls[11] = Chapter12.class;
		cls[12] = Chapter13.class;
		cls[13] = Chapter14.class;
		cls[14] = Chapter15.class;
		cls[15] = Chapter16.class;
		cls[16] = Chapter17.class;
		cls[17] = Chapter18.class;
		cls[18] = Chapter19.class;
		cls[19] = Chapter20.class;
		cls[20] = Chapter21.class;
		cls[21] = Summarize.class;
		cls[22] = Audition.class;
		//按钮点击循环监听
		try
		{
			final int subs;
			for (subs = 0; subs < btn_c.length; subs++)
			{
				btn_c[subs].setOnClickListener(new OnClickListener()
				{
					public void onClick(View v)
					{
						try
						{
							startActivity(new Intent(Chapter.this,cls[subs]));
							clickcls(subs + 1);
						}
						catch(Exception e)
						{
							Toast.makeText(getApplicationContext(),"未知错误",Toast.LENGTH_SHORT).show();
						}
					}
				});
			}
		}
		catch (Exception e)
		{
			Toast.makeText(getApplicationContext(), "未知异常", Toast.LENGTH_SHORT).show();
		}
		/*btn_c[0].setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				startActivity(new Intent(Chapter.this, Chapter01.class));
				clickcls(1);
			}
		});
		btn_c[1].setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				if (thisCap >= 1)
				{
					startActivity(new Intent(Chapter.this, Chapter02.class));
					clickcls(2);
				}
				else
					toErr();
			}
		});
		btn_c[2].setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				if (thisCap >= 2)
				{
					startActivity(new Intent(Chapter.this, Chapter03.class));
					clickcls(3);
				}
				else
					toErr();
			}
		});
		btn_c[3].setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				if (thisCap >= 3)
				{
					startActivity(new Intent(Chapter.this, Chapter04.class));
					clickcls(4);
				}
				else
					toErr();
			}
		});
		btn_c[4].setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				if (thisCap >= 4)
				{
					startActivity(new Intent(Chapter.this, Chapter05.class));
					clickcls(5);
				}
				else
					toErr();
			}
		});
		btn_c[5].setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				if (thisCap >= 5)
				{
					startActivity(new Intent(Chapter.this, Chapter06.class));
					clickcls(6);
				}
				else
					toErr();
			}
		});
		btn_c[6].setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				if (thisCap >= 6)
				{
					startActivity(new Intent(Chapter.this, Chapter07.class));
					clickcls(7);
				}
				else
					toErr();
			}
		});
		btn_c[7].setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				if (thisCap >= 7)
				{
					startActivity(new Intent(Chapter.this, Chapter08.class));
					clickcls(8);
				}
				else
					toErr();
			}
		});
		btn_c[8].setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				if (thisCap >= 8)
				{
					startActivity(new Intent(Chapter.this, Chapter09.class));
					clickcls(9);
				}
				else
					toErr();
			}
		});
		btn_c[9].setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				if (thisCap >= 9)
				{
					startActivity(new Intent(Chapter.this, Chapter10.class));
					clickcls(10);
				}
				else
					toErr();
			}
		});
		btn_c[10].setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				if (thisCap >= 10)
				{
					startActivity(new Intent(Chapter.this, Chapter11.class));
					clickcls(11);
				}
				else
					toErr();
			}
		});
		btn_c[11].setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				if (thisCap >= 11)
				{
					startActivity(new Intent(Chapter.this, Chapter12.class));
					clickcls(12);
				}
				else
					toErr();
			}
		});
		btn_c[12].setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				if (thisCap >= 12)
				{
					startActivity(new Intent(Chapter.this, Chapter13.class));
					clickcls(13);
				}
				else
					toErr();
			}
		});
		btn_c[13].setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				if (thisCap >= 13)
				{
					startActivity(new Intent(Chapter.this, Chapter14.class));
					clickcls(14);
				}
				else
					toErr();
			}
		});
		btn_c[14].setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				if (thisCap >= 14)
				{
					startActivity(new Intent(Chapter.this, Chapter15.class));
					clickcls(15);
				}
				else
					toErr();
			}
		});
		btn_c[15].setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				if (thisCap >= 15)
				{
					startActivity(new Intent(Chapter.this, Chapter16.class));
					clickcls(16);
				}
				else
					toErr();
			}
		});
		btn_c[16].setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				if (thisCap >= 16)
				{
					startActivity(new Intent(Chapter.this, Chapter17.class));
					clickcls(17);
				}
				else
					toErr();
			}
		});
		btn_c[17].setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				if (thisCap >= 17)
				{
					startActivity(new Intent(Chapter.this, Chapter18.class));
					clickcls(18);
				}
				else
					toErr();
			}
		});
		btn_c[18].setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				if (thisCap >= 18)
				{
					startActivity(new Intent(Chapter.this, Chapter19.class));
					clickcls(19);
				}
				else
					toErr();
			}
		});
		btn_c[19].setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				if (thisCap >= 19)
				{
					startActivity(new Intent(Chapter.this, Chapter20.class));
					clickcls(20);
				}
				else
					toErr();
			}
		});
		btn_c[20].setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				if (thisCap >= 20)
				{
					startActivity(new Intent(Chapter.this, Chapter21.class));
					clickcls(21);
				}
				else
					toErr();
			}
		});
	}
	
	public void onListener(int capter)
	{
		if (thisCap >= capter)
		{
			startActivity(new Intent(Chapter.this, cls[capter].getClass()));
			clickcls(capter + 1);
		}
		else
			toErr();*/
	}
	
	private void clickcls(int item)
	{
		/*Intent intent = new Intent();
		intent.setClass(Chapter.this, cls[item]);
		startActivity(intent);*/
		edt = spf.edit();
		edt.putInt("chapter",item);
		edt.commit();
		thisCap = item;
	}
	
	/*protected void onBanner()
	{
		RelativeLayout banner = (RelativeLayout) findViewById(R.id.banner2);
		//AdView adv = new AdView(this, AdSize.BANNER, "1101326556", "9007479618592438842");
		AdView adv = new AdView(this, AdSize.BANNER, "1150078134", "9079537216925334074");
		banner.addView(adv);
		AdRequest adr = new AdRequest();
		adr.setRefresh(30);
		adv.setAdListener(new AdListener()
		{
			@Override
			public void onNoAd()
			{
				Log.i("no ad cb:","no");
			}
			@Override
			public void onAdReceiv()
			{
				Log.i("ad recv cb","revc");
			}
		});
		adv.fetchAd(adr);
	}*/
	public void toErr()
	{
		Toast.makeText(getApplicationContext(),"请按照章节依次学习，谢谢！",Toast.LENGTH_SHORT).show();
	}
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		/*if(keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN)
		{
			startActivity(new Intent(Chapter.this, Main.class));
			finish();
			return true;
		}*/
		return super.onKeyDown(keyCode, event);
	}
}
