package com.vbea.java21;

import android.app.Activity;
import android.os.Bundle;

public class Chapter07 extends Activity
{
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.chapter07);
	}
}
