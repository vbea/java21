package com.vbea.java21;

import android.app.Activity;
import android.os.*;
import android.widget.*;
import android.view.View;
import android.view.View.*;
import android.content.*;
import android.content.SharedPreferences.Editor;
import java.util.Date;
import java.util.Locale;
import java.text.SimpleDateFormat;

public class HadInvitation extends Activity
{
	private EditText edt1, edt2, edt3, edt4;
	private Button cancel;
	private Button btn_ok;
	private String date;
	private boolean iVer = true;
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		//this.setTheme(android.R.style.Theme_Dialog);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.forces);

		edt1 = (EditText) findViewById(R.id.psd_edit03);
		edt2 = (EditText) findViewById(R.id.psd_edit04);
		edt3 = (EditText) findViewById(R.id.psd_edit05);
		edt4 = (EditText) findViewById(R.id.psd_edit06);
		cancel = (Button) findViewById(R.id.psd_btn02);
		btn_ok = (Button) findViewById(R.id.psd_btn03);

		cancel.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				finish();
			}
		});
		btn_ok.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				try
				{
					if (edt1.getText().length() < 4 || edt2.getText().length() < 4 || edt3.getText().length() < 4 || edt4.getText().length() < 4)
					{
						Toast.makeText(getApplicationContext(), "请输入您的身份标识(可随意输入)", Toast.LENGTH_SHORT).show();
							return;
					}
					else//判断激活码是否有效
					{
						SimpleDateFormat sdf = new SimpleDateFormat("",Locale.SIMPLIFIED_CHINESE);
						sdf.applyLocalizedPattern("yyyy-MM-dd");
						date = sdf.format(new Date());
						//Toast.makeText(getApplicationContext(), date+"/"+date2+"/"+date3, Toast.LENGTH_SHORT).show();
						Toast.makeText(getApplicationContext(), "恭喜你，激活成功，现在就开始学习吧！", Toast.LENGTH_SHORT).show();
						SharedPreferences sdp = getSharedPreferences("java21", Context.MODE_PRIVATE);
						Editor editor = sdp.edit();
						editor.putBoolean("isActive", true);
						editor.putString("psd", edt1.getText().toString()+"-"+edt2.getText().toString()+"-"+edt3.getText().toString()+"-"+edt4.getText().toString());
						editor.putString("date", date);
						editor.putBoolean("iHer",iVer);
						editor.commit();
						finish();
					}
				}
				catch (Exception e)
				{
					Toast.makeText(getApplicationContext(), "激活失败，激活码输入格式不正确！", Toast.LENGTH_LONG).show();
					finish();
				}
			}
		});
	}
}
