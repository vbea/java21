package com.vbea.java21;

import android.app.Activity;
import android.os.*;
import android.widget.*;
import android.view.View;
import android.view.View.*;
import android.content.*;
import android.content.SharedPreferences.Editor;
import java.util.Date;
import java.util.Locale;
import java.text.SimpleDateFormat;

public class Invitation extends Activity
{
	private EditText edt1, edt2, edt3, edt4;
	private Button cancel;
	private Button btn_ok;
	private String date;
	private boolean iVer = false;
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		//this.setTheme(android.R.style.Theme_Dialog);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.invite);
		
		edt1 = (EditText) findViewById(R.id.psd_edit03);
		edt2 = (EditText) findViewById(R.id.psd_edit04);
		edt3 = (EditText) findViewById(R.id.psd_edit05);
		edt4 = (EditText) findViewById(R.id.psd_edit06);
		cancel = (Button) findViewById(R.id.psd_btn02);
		btn_ok = (Button) findViewById(R.id.psd_btn03);
		
		cancel.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				finish();
			}
		});
		btn_ok.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				try
				{
					if (edt1.getText().length() < 4 || edt2.getText().length() < 4 || edt3.getText().length() < 4 || edt4.getText().length() < 4)
					{
						Toast.makeText(getApplicationContext(), "请将激活码填写完整", Toast.LENGTH_SHORT).show();
						return;
					}
					//判断激活码是否有效
					if ((edt1.getText().toString().equals("java") || edt1.getText().toString().equals("Java")) && ed3s(edt3.getText().toString()))
					{
						if (ed2s(Integer.parseInt(edt2.getText().toString())) && ed4s(Integer.parseInt(edt4.getText().toString())) )
						{
							SimpleDateFormat sdf = new SimpleDateFormat("",Locale.SIMPLIFIED_CHINESE);
							sdf.applyLocalizedPattern("yyyy-MM-dd");
							date = sdf.format(new Date());
							//Toast.makeText(getApplicationContext(), date+"/"+date2+"/"+date3, Toast.LENGTH_SHORT).show();
							Toast.makeText(getApplicationContext(), "恭喜你，激活成功，现在就开始学习吧！", Toast.LENGTH_SHORT).show();
							SharedPreferences sdp = getSharedPreferences("java21", Context.MODE_PRIVATE);
							Editor editor = sdp.edit();
							editor.putBoolean("isActive", true);
							editor.putString("psd", edt1.getText().toString()+"-"+edt2.getText().toString()+"-"+edt3.getText().toString()+"-"+edt4.getText().toString());
							editor.putString("date", date);
							editor.putBoolean("iVer",iVer);
							editor.putBoolean("iHer",false);
							editor.commit();
							finish();
						}
						else
						{
							Toast.makeText(getApplicationContext(), "抱歉，该激活码已被使用！", Toast.LENGTH_LONG).show();
							finish();
						}
					}
					else
					{
						Toast.makeText(getApplicationContext(), "抱歉，激活码输入错误，请重新输入！", Toast.LENGTH_LONG).show();
						finish();
					}
				}
				catch (Exception e)
				{
					Toast.makeText(getApplicationContext(), "激活失败，激活码输入格式不正确！", Toast.LENGTH_LONG).show();
					finish();
				}
			}
		});
	}
	private boolean ed4s(int p1)
	{
		Date dat1 = new Date();
		int date2 = dat1.getDate() * 100;
		boolean b1 = false;
		if (p1 * 5 == date2)
		{
			b1 = true;
		}
		if(p1 == Integer.parseInt(edt2.getText().toString())+date2)
		{
			iVer = true;
			b1 = true;
		}
		return b1;
	}
	private boolean ed3s(String s1)
	{
		boolean b1 = false;
		String [] strs = {"00","01","10","11","20","12","21","02","22"};
		for (int i=0;i<strs.length;i++)
		{
			if (s1.substring(0, 2).equals(strs[i]))
			{
				b1 = true;
				break;
			}
		}
		return b1;
	}
	private boolean ed2s(int p1)
	{
		boolean b2 = false;
		Date dat2 = new Date();
		int date3 = dat2.getMonth();
		if (p1 / 5 == date3)
		{
			b2 = true;
		}
		return b2;
	}
}
