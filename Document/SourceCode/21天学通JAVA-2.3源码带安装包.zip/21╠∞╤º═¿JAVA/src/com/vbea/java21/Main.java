package com.vbea.java21;

import java.util.Date;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.widget.Toast;
import android.widget.*;
import android.view.View.*;
import android.view.*;
import android.content.Intent;
import android.content.*;
import android.net.*;

import com.ant.liao.GifView;
import com.ant.liao.GifView.GifImageType;
import com.tencent.stat.StatService;//腾讯云接入
import com.qq.e.ads.AdRequest;//广点通接入
import com.qq.e.ads.AdServiceManager;
import com.qq.e.ads.AdSize;
import com.qq.e.ads.AdView;
import com.qq.e.ads.*;
import android.util.*;

public class Main extends Activity
{
	private ProgressBar studyHard;
	private long exitTime = 0;
	private int pro_default = 23;
	private int pro_study = 0;
	private boolean hard;
	private boolean herd;
	private SharedPreferences spt;
	private TextView stxt;
	private Button btn_start, btn_apidoc, btn_help, btn_about;
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		StatService.trackCustomEvent(this, "onCreate", "");
		//onBanner();
		btn_start = (Button) findViewById(R.id.btn_start);
		btn_apidoc = (Button) findViewById(R.id.btn_api);
		btn_help = (Button) findViewById(R.id.btn_help);
		btn_about = (Button) findViewById(R.id.btn_about);
		stxt = (TextView) findViewById(R.id.textStudy);
		GifView gif1 = (GifView) findViewById(R.id.gif1);
		GifView gif2 = (GifView) findViewById(R.id.gif2);
		gif1.setGifImage(R.drawable.java21_logo);
		gif1.showAnimation();//显示动画
		//gif1.showCover();//关闭动画
		gif2.setGifImage(R.drawable.java21);
		gif2.showAnimation();
		
		startText();
		
		btn_start.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				if (hard)
				{
					/*if (isNet())
					 {
					 startActivity(new Intent(Main.this, NotNetError.class));
					 }
					 else
					 {*/
					startActivity(new Intent(Main.this, Chapter.class));
					//Main.this.finish();
				}
				else
				{
					startActivity(new Intent(Main.this, Invitation.class));
				}
			}
		});
		btn_apidoc.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				Date date = new Date();
				if (herd || (date.getDate() <= 30 && date.getMonth() <= 10))
				{
					if (herd)
						startActivity(new Intent(Main.this, ApiWord.class));
					else
					{
						startActivity(new Intent(Main.this, ApiWord.class));
						Toast.makeText(getApplicationContext(),"API文档限时免激活还剩 "+(30-date.getDate())+" 天",Toast.LENGTH_SHORT).show();
					}
				}
				else
					Toast.makeText(getApplicationContext(),"标准版不支持在线文档，请升级至完整版或使用正德应用查看",Toast.LENGTH_SHORT).show();
			}
		});
		btn_help.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				startActivity(new Intent(Main.this, Help.class));
			}
		});
		btn_about.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				startActivity(new Intent(Main.this, About.class));
			}
		});
	}
	protected void onBanner()
	{
		RelativeLayout banner = (RelativeLayout) findViewById(R.id.banner1);
		AdView adv = new AdView(this, AdSize.BANNER, "1101326556", "9079537212630366778");
		banner.addView(adv);
		AdRequest adr = new AdRequest();
		adr.setRefresh(30);
		/*adv.setAdListener(new AdListener()
		{
			@Override
			public void onNoAd()
			{
				Log.i("no ad cb:","no");
			}
			@Override
			public void onAdReceiv()
			{
				Log.i("ad recv cb","revc");
			}
		});*/
		adv.fetchAd(adr);
	}
	public void startText()
	{
		studyHard = (ProgressBar) findViewById(R.id.studyBar);
		spt = getSharedPreferences("java21", Context.MODE_PRIVATE);
		pro_study = spt.getInt("chapter", 0);
		hard = spt.getBoolean("isActive", false);
		herd = spt.getBoolean("iVer",false);
		if (hard)
		{
			studyHard.setSecondaryProgress(pro_default);
			studyHard.setProgress(pro_study);
			if (pro_study != pro_default)
			{
				stxt.setText(getResources().getString(R.string.prostudy) +"("+pro_study+"/"+pro_default+")");
			}
			else
			{
				stxt.setText(getResources().getString(R.string.prosucees)+"("+pro_study+"/"+pro_default+")");
			}
		}
		else
		{
			studyHard.setSecondaryProgress(0);
			studyHard.setProgress(0);
			stxt.setText("");
		}
	}
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		if(keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN)
		{
			if((System.currentTimeMillis() - exitTime) > 2000)
			{
				Toast.makeText(Main.this,"再按一次退出程序",Toast.LENGTH_SHORT).show();
				exitTime = System.currentTimeMillis();
			}
			else
			{
				onDestroyd();
			}
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
	/*public boolean isNet()
	{
		ConnectivityManager zdapp = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		if (zdapp == null)
		{
			return false;
		}
		else
		{
			NetworkInfo[] info = zdapp.getAllNetworkInfo();
			if (info != null)
			{
				for (int i=0; i<info.length; i++)
				{
					if (info[i].getState() == NetworkInfo.State.CONNECTED)
					{
						return true;
					}
				}
				//zdapp.getActiveNetworkInfo().isAvailable()
			}
		}
		return false;
	}*/
	@Override
	protected void onResume()
	{
		super.onResume();
		StatService.onResume(this);
		startText();
	}
	@Override
	protected void onPause()
	{
		super.onPause();
		StatService.onPause(this);
	}

	@Override
	protected void onDestroyd()
	{
		//释放占用的内存资源
		finish();
		android.os.Process.killProcess(android.os.Process.myPid());
		super.onDestroy();
		//System.exit(0);
	}
}
