package com.vbea.java21;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.content.Context;
import android.content.SharedPreferences;
import android.app.AlertDialog.Builder;
import android.content.*;
import com.tencent.stat.StatService;
import android.widget.*;
import java.util.Timer;
import java.util.TimerTask;
import android.os.*;

public class MainActivity extends Activity
{
	private TextView retry;
	private int aTime;
	private Timer timer;
	/**Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome);
		retry = (TextView) findViewById(R.id.text_retry);
		StatService.trackCustomEvent(this, "onCreate", "");
		SharedPreferences spf = getSharedPreferences("java21", Context.MODE_PRIVATE);
		boolean act = spf.getBoolean("isActive", false);
		try
		{
			//Thread.sleep(3000);
			if (isNet(getApplicationContext()) || act)
			{
				timer = new Timer(true);
				timer.schedule(task, 0, 300);
				//Thread.sleep(3000);
				/*Intent intent=new Intent(MainActivity.this,Main.class);
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
				startActivity(intent);
				MainActivity.this.finish();*/
			}
			else
			{
				startActivity(new Intent(MainActivity.this, NotNetError.class));
				retry.setText("加载失败，请退出后重试");
				//MainActivity.this.finish();
			}
		}
		catch(Exception e)
		{
			// TODO Auto-gener2;ated catch block 
			//e.printStackTrace();
		}
	}
	public static boolean isNet(Context con)
	{
		ConnectivityManager zdapp = (ConnectivityManager) con.getSystemService(Context.CONNECTIVITY_SERVICE);
		if (zdapp == null)
		{
			return false;
		}
		else
		{
			NetworkInfo[] info = zdapp.getAllNetworkInfo();
			if (info != null)
			{
				for (int i=0; i<info.length; i++)
				{
					if (info[i].getState() == NetworkInfo.State.CONNECTED)
					{
						return true;
					}
				}
			//zdapp.getActiveNetworkInfo().isAvailable()
			}
		}
		return false;
	}
	Handler handler = new Handler()
	{
		public void handleMessage(Message msg)
		{
			switch (msg.what)
			{
				case 1:
					runText();
					break;
			}
			super.handleMessage(msg);
		}
	};
	TimerTask task = new TimerTask()
	{
		public void run()
		{
			Message message = new Message();
			message.what = 1;
			handler.sendMessage(message);
		}
	};
	public void runText()
	{
		if (aTime == 0)
		{
			retry.setText("加载中"+" "+" "+" ");
			aTime = 1;
		}
		else if (aTime == 1 || aTime == 4)
		{
			retry.setText("加载中."+" "+" ");
			aTime++;
		}
		else if (aTime == 2 || aTime == 5)
		{
			retry.setText("加载中.."+" ");
			aTime++;
		}
		else if (aTime == 3 || aTime == 6)
		{
			retry.setText("加载中...");
			aTime++;
		}
		else if (aTime == 7)
		{
			retry.setText("正在载入");
			task.cancel();
			Intent intent=new Intent(MainActivity.this,Main.class);
			overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
			startActivity(intent);
			MainActivity.this.finish();
			//timer.cancel();
		}
	}
}
