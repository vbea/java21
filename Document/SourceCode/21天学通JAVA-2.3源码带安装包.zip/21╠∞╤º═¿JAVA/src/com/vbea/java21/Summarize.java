package com.vbea.java21;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.widget.TextView;

public class Summarize extends Activity
{
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.webview);
		
		TextView title = (TextView) findViewById(R.id.webTitle);
		WebView webview = (WebView) findViewById(R.id.webview1);

		title.setText("Java知识总结");
		webview.loadUrl("file:///android_asset/java/summarize.htm");

	}
	
}
