package com.qq.e.v2.managers.plugin.a;

public class a
{
	String k;
	public a(String _k)
	{
		k = _k;
	}
	
	public c set(String p)
	{
		return new c(p);
	}
	
	public final class c
	{
		public c(String ii)
		{
			i = ii;
		}
		String i = "";
		public b get()
		{
			return new b(k, i);
		}
	}
}
