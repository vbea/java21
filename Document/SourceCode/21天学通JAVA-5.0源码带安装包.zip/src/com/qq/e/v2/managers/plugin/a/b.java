package com.qq.e.v2.managers.plugin.a;

public class b
{
	String k = "";
	String d = "";
	String p = "";
	public b(String _k, String _p)
	{
		k = _k;
		p = _p;
	}
	
	public void set(String _d)
	{
		d = _d;
	}
	
	public boolean get()
	{
		return true;
	}
}
