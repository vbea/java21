package com.qq.e.v2.managers.plugin.a;

public class plugins
{
	b b = new b("","");
}
