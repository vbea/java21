package com.vbea.java21;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Build;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.content.Intent;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.DialogInterface;
import android.view.View;
import android.view.View.OnClickListener;

public class About extends Activity
{
	SharedPreferences spt;
	TextView txt_Invate,txt_IDate,txt_Iver,txt_Iname,txt_Ipro,txt_feild,txt_feild2;
	Button btn_active,btn_change;
	Editor sh_edt;
	private RelativeLayout title;
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH)
			this.setTheme(android.R.style.Theme_Holo_Light_NoActionBar);
		else
			setTheme(android.R.style.Theme_Light_NoTitleBar);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.about);
		
		spt = getSharedPreferences("java21", Context.MODE_PRIVATE);
		sh_edt = spt.edit();
		title = (RelativeLayout) findViewById(R.id.bg_title);
		txt_Invate = (TextView) findViewById(R.id.txt_invate);
		txt_IDate = (TextView) findViewById(R.id.txt_iTime);
		txt_Iver = (TextView) findViewById(R.id.txt_iVersion);
		txt_Iname = (TextView) findViewById(R.id.abt_appName);
		txt_Ipro = (TextView) findViewById(R.id.txt_iPro);
		txt_feild = (TextView) findViewById(R.id.txt_fieldKey);
		txt_feild2 = (TextView) findViewById(R.id.txt_fieldKey2);
		btn_active = (Button) findViewById(R.id.abt_btnUnact);
		btn_change = (Button) findViewById(R.id.abt_btnChange);
		isActive();
		btn_active.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				new AlertDialog.Builder(About.this)
				.setTitle("提示")
				.setMessage("确认要清除注册信息？")
				.setPositiveButton("确定", new DialogInterface.OnClickListener()
				{
					public void onClick(DialogInterface dialog, int swich)
					{
						sh_edt.putString("date","-");
						sh_edt.putString("key","");
						sh_edt.putBoolean("active", false);
						sh_edt.putInt("chapter",0);
						sh_edt.commit();
						isActive();
					}
				})
				.setNegativeButton("取消",null)
				.show();
			}
		});
		
		btn_change.setOnClickListener(new OnClickListener()
		{
			public void onClick(View p)
			{
				startActivity(new Intent(About.this, Invitation.class));
			}
		});
		
		ImageButton back = (ImageButton) findViewById(R.id.btn_back);
		back.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				finish();
			}
		});
	}
	private void isActive()
	{
		//TextView txt_Invate = (TextView) findViewById(R.id.txt_invate);
		//TextView txt_IDate = (TextView) findViewById(R.id.txt_iTime);
		//SharedPreferences spt = getSharedPreferences("java21", Context.MODE_PRIVATE);
		boolean isa = spt.getBoolean("active",false);
		txt_IDate.setText(spt.getString("date","-"));
		txt_Iver.setText(spt.getString("key", ""));
		int color = MyThemes.getColor(this);
		txt_Invate.setTextColor(color);
		txt_IDate.setTextColor(color);
		txt_Iver.setTextColor(color);
		txt_Ipro.setTextColor(color);
		txt_feild.setTextColor(color);
		txt_feild2.setTextColor(color);
		if (isa)
		{
			txt_Invate.setText("已应用序列号");
			btn_active.setVisibility(View.VISIBLE);
			btn_change.setText(R.string.changed);
			if (spt.getBoolean("pro", false))
				txt_Ipro.setText("专业版");
			else
				txt_Ipro.setText("标准版");
			txt_Iname.setText(getString(R.string.app_name) + "-" + txt_Ipro.getText().toString());
		}
		else
		{
			txt_Invate.setText("尚未注册");
			btn_active.setVisibility(View.GONE);
			btn_change.setText(R.string.actived);
		}
	}

	@Override
	protected void onPause()
	{
		// TODO: Implement this method
		super.onPause();
	}

	@Override
	protected void onResume()
	{
		MyThemes.setThemeColor(this, title);
		isActive();
		super.onResume();
	}

	@Override
	protected void onDestroy()
	{
		// TODO: Implement this method
		super.onDestroy();
	}
}
