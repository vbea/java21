package com.vbea.java21;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.widget.TextView;
import android.widget.ImageButton;
import android.widget.*;

public class Audition extends Activity
{
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.webview);
		
		TextView title = (TextView) findViewById(R.id.webTitle);
		WebView webview = (WebView) findViewById(R.id.webview1);
		
		title.setText(R.string.cap_22);
		webview.loadUrl("file:///android_asset/java/java_audition.htm");
		ImageButton back = (ImageButton) findViewById(R.id.btn_back);
		back.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				finish();
			}
		});
	}

	@Override
	protected void onResume()
	{
		RelativeLayout title = (RelativeLayout) findViewById(R.id.bg_title);
		MyThemes.setThemeColor(this, title);
		super.onResume();
	}
	
}
