package com.vbea.java21;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.view.View;
import android.content.Intent;
import java.lang.Class;
import java.util.List;
import android.widget.*;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.view.KeyEvent;

import com.vbea.java21.classes.Common;

public class Chapter extends Activity
{
	private String[] title;
	private ListView mList;
	private SharedPreferences spf;
	private RelativeLayout titles;
	private ProgressBar studyHard;
	@Override
	public void onCreate(Bundle savedIntanceState)
	{
		setTheme(android.R.style.Theme_DeviceDefault_Light_NoActionBar);
		super.onCreate(savedIntanceState);
		setContentView(R.layout.chapter);
		//onBanner();
		titles = (RelativeLayout) findViewById(R.id.bg_title);
		spf = getSharedPreferences("java21", Context.MODE_PRIVATE);
		mList = (ListView) findViewById(R.id.chapterList);
		studyHard = (ProgressBar) findViewById(R.id.studyBar);
		ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_expandable_list_item_1);
		//标题关联
		title = getResources().getStringArray(R.array.array_chapter);
		adapter.addAll(title);
		mList.setAdapter(adapter);
		
		mList.setOnItemClickListener(new AdapterView.OnItemClickListener()
		{
			@Override
			public void onItemClick(AdapterView<?> p1, View p2, int p3, long p4)
			{
				try
				{
					if (!Common.APP_THEME)
					{
						Common.isActivity(spf.getString("key", ""), spf.getString("date",""));
						if (!Common.APP_THEME)
						{
							throw new Exception();
						}
					}
					if (Common.IS_ACTIVE || (p3 - Common.CHAPTER) < 1)
					{
						clickcls(p3 + 1);
						Intent intent1 = new Intent();
						intent1.setClass(Chapter.this,Chapter01.class);
						Bundle b1 = new Bundle();
						b1.putInt("A2E4ACD4AB3ACA23A4C5F6B",p3);
						intent1.putExtras(b1);
						startActivity(intent1);
					}
					else
						toErr();
				}
				catch(Exception e)
				{
					Toast.makeText(getApplicationContext(),"未知错误",Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		ImageButton back = (ImageButton) findViewById(R.id.btn_back);
		back.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				finish();
			}
		});
	}
	
	private void clickcls(int item)
	{
		Common.CHAPTER = item;
	}
	
	private void init()
	{
		studyHard.setProgress(Common.CHAPTER);
	}
	
	/*protected void onBanner()
	{
		RelativeLayout banner = (RelativeLayout) findViewById(R.id.banner2);
		//AdView adv = new AdView(this, AdSize.BANNER, "1101326556", "9007479618592438842");
		AdView adv = new AdView(this, AdSize.BANNER, "1150078134", "9079537216925334074");
		banner.addView(adv);
		AdRequest adr = new AdRequest();
		adr.setRefresh(30);
		adv.setAdListener(new AdListener()
		{
			@Override
			public void onNoAd()
			{
				Log.i("no ad cb:","no");
			}
			@Override
			public void onAdReceiv()
			{
				Log.i("ad recv cb","revc");
			}
		});
		adv.fetchAd(adr);
	}*/
	public void toErr()
	{
		Toast.makeText(getApplicationContext(),R.string.ch_noregist,Toast.LENGTH_SHORT).show();
	}
	
	@Override
	protected void onResume()
	{
		MyThemes.setThemeColor(this, titles);
		init();
		super.onResume();
	}

	@Override
	protected void onDestroy()
	{
		super.onDestroy();
	}
	
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		/*if(keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN)
		{
			startActivity(new Intent(Chapter.this, Main.class));
			finish();
			return true;
		}*/
		return super.onKeyDown(keyCode, event);
	}
}
