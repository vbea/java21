package com.vbea.java21;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.content.Intent;
import com.vbea.java21.classes.Common;

public class Chapter01 extends Activity
{
	private int A2E4ACD4AB3ACA23A4C5F6B = 0;
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		try
		{
			A2E4ACD4AB3ACA23A4C5F6B = getIntent().getExtras().getInt("A2E4ACD4AB3ACA23A4C5F6B");
			getView();
		}
		catch (Exception e)
		{
			finish();
		}
		
		ImageButton back = (ImageButton) findViewById(R.id.btn_back);
		Button next = (Button) findViewById(R.id.btn_cnext);
		back.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				finish();
			}
		});
		next.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				Intent intent1 = new Intent();
				intent1.setClass(Chapter01.this,Chapter01.class);
				Bundle b1 = new Bundle();
				b1.putInt("A2E4ACD4AB3ACA23A4C5F6B",A2E4ACD4AB3ACA23A4C5F6B+1);
				intent1.putExtras(b1);
				startActivity(intent1);
				finish();
			}
		});
	}
	
	private void getView()
	{
		//选择章节
		if (!Common.APP_THEME)
		{
			setContentView(R.layout.chapter01);
			return;
		}
		switch (A2E4ACD4AB3ACA23A4C5F6B)
		{
			case 0:
				setContentView(R.layout.chapter01);
				break;
			case 1:
				setContentView(R.layout.chapter02);
				break;
			case 2:
				setContentView(R.layout.chapter03);
				break;
			case 3:
				setContentView(R.layout.chapter04);
				break;
			case 4:
				setContentView(R.layout.chapter05);
				break;
			case 5:
				setContentView(R.layout.chapter06);
				break;
			case 6:
				setContentView(R.layout.chapter07);
				break;
			case 7:
				setContentView(R.layout.chapter08);
				break;
			case 8:
				setContentView(R.layout.chapter09);
				break;
			case 9:
				setContentView(R.layout.chapter10);
				break;
			case 10:
				setContentView(R.layout.chapter11);
				break;
			case 11:
				setContentView(R.layout.chapter12);
				break;
			case 12:
				setContentView(R.layout.chapter13);
				break;
			case 13:
				setContentView(R.layout.chapter14);
				break;
			case 14:
				setContentView(R.layout.chapter15);
				break;
			case 15:
				setContentView(R.layout.chapter16);
				break;
			case 16:
				setContentView(R.layout.chapter17);
				break;
			case 17:
				setContentView(R.layout.chapter18);
				break;
			case 18:
				setContentView(R.layout.chapter19);
				break;
			case 19:
				setContentView(R.layout.chapter20);
				break;
			case 20:
				setContentView(R.layout.chapter21);
				break;
			default:
				setContentView(R.layout.machine);
				break;
		}
	}
	
	@Override
	protected void onResume()
	{
		RelativeLayout title = (RelativeLayout) findViewById(R.id.bg_title);
		MyThemes.setThemeColor(this, title);
		Common.CHAPTER = A2E4ACD4AB3ACA23A4C5F6B+1;
		super.onResume();
	}

	@Override
	protected void onDestroy()
	{
		super.onDestroy();
	}
}
