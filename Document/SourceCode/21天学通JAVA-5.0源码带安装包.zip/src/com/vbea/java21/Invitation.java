package com.vbea.java21;

import java.util.Date;
import java.text.SimpleDateFormat;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.view.View;
import android.view.View.OnClickListener;
import android.content.Context;
import android.content.SharedPreferences;
import android.text.Editable;
import android.text.TextWatcher;

import com.vbea.java21.classes.DecHelper;
import com.vbea.java21.classes.Common;

public class Invitation extends Activity
{
	private EditText edt1;
	private Button cancel;
	private Button btn_ok;
	private String date;
	private String txt_keys = "";
	private SharedPreferences sdp;
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH)
			this.setTheme(android.R.style.Theme_Holo_Light_Dialog_NoActionBar);
		else
			setTheme(android.R.style.Theme_Light_NoTitleBar);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.invite);
		
		edt1 = (EditText) findViewById(R.id.psd_edit03);
		cancel = (Button) findViewById(R.id.psd_btn02);
		btn_ok = (Button) findViewById(R.id.psd_btn03);
		
		sdp = getSharedPreferences("java21", Context.MODE_PRIVATE);
		edt1.setText(sdp.getString("key", ""));
		if (edt1.getText().toString().length() > 0)
			btn_ok.setEnabled(true);
		cancel.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				finish();
			}
		});
		btn_ok.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				if (edt1.getText().length() < 19)
				{
					Toast.makeText(getApplicationContext(), "请将激活码填写完整", Toast.LENGTH_SHORT).show();
					return;
				}
				//判断激活码是否有效
				try
				{
					DecHelper dec = new DecHelper("java");
					String [] keys = edt1.getText().toString().split("-");
					if (keys.length == 4)
					{
						String password = dec.decrypt(keys[0]+keys[1]+keys[2]+keys[3]);
						SimpleDateFormat sdf = new SimpleDateFormat("MMdd");
						SimpleDateFormat spf2 = new SimpleDateFormat("yyyy-MM-dd");
						date = spf2.format(new Date());
						if (password.indexOf(sdf.format(new Date())) >= 0)
						{
							Toast.makeText(getApplicationContext(), "恭喜你，激活成功，现在就开始学习吧！", Toast.LENGTH_SHORT).show();
							Common.APP_THEME = true;
							SharedPreferences.Editor editor = sdp.edit();
							editor.putBoolean("active", true);
							editor.putString("key", edt1.getText().toString());
							editor.putString("date", date);
							editor.putBoolean("pro", password.toLowerCase().endsWith("p"));
							editor.commit();
							finish();
						}
						else
						{
							Toast.makeText(getApplicationContext(), "抱歉，该注册码已过期！", Toast.LENGTH_LONG).show();
							finish();
						}
					}
					else
					{
						Toast.makeText(getApplicationContext(), "抱歉，注册码输入错误，请重新输入！", Toast.LENGTH_LONG).show();
						edt1.setText("");
					}
				}
				catch (Exception e)
				{
					Toast.makeText(getApplicationContext(), "无效的注册码，请重新输入！", Toast.LENGTH_LONG).show();
					edt1.setText("");
				}
			}
		});
		edt1.addTextChangedListener(new TextWatcher()
		{
			@Override
			public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4)
			{
				
			}

			@Override
			public void onTextChanged(CharSequence p1, int p2, int p3, int p4)
			{
				if (p1.length() > 0)
					btn_ok.setEnabled(true);
				else
					btn_ok.setEnabled(false);
			}
			
			@Override
			public void afterTextChanged(Editable p1)
			{
				
			}
		});
	}
}
