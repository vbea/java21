package com.vbea.java21;

import java.util.Calendar;
import java.util.Date;
import java.text.SimpleDateFormat;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ImageButton;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.Toast;
import android.view.View;
import android.view.LayoutInflater;
import android.view.animation.AnticipateOvershootInterpolator;
import android.content.DialogInterface;
import android.content.SharedPreferences;

import com.vbea.java21.classes.DecHelper;
import com.vbea.java21.wheel.WheelView;
import com.vbea.java21.wheel.StrericWheelAdapter;
import com.vbea.java21.wheel.OnWheelChangedListener;

public class Machine extends Activity
{
	private String[] years = {"2013","2014","2015","2016","2017","2018","2019","2020"};
	private String[] months = {"01","02","03","04","05","06","07","08","09","10","11","12"};
	private String[] days;
	private int mYear=0, mMonth=0, mDay=0;
	private WheelView yearWheel, monthWheel, dayWheel;
	private SharedPreferences spf;
	private TextView txtDate;
	private EditText edtKey;
	private RelativeLayout title;
	private AlertDialog.Builder builder;
	private AlertDialog dialog;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.machine);
		
		final Date dated = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy");
		mYear = getYearsItem(sdf.format(dated));
		mMonth = dated.getMonth();
		mDay = dated.getDate() - 1;
		
		ImageButton back = (ImageButton) findViewById(R.id.btn_back);
		Button btnDate = (Button) findViewById(R.id.btn_selectDate);
		Button btnSubm = (Button) findViewById(R.id.btn_commitRegist);
		TextView field = (TextView) findViewById(R.id.txt_fieldKey);
		title = (RelativeLayout) findViewById(R.id.bg_title);
		edtKey = (EditText) findViewById(R.id.edt_key);
		txtDate = (TextView) findViewById(R.id.txt_redate);
		spf = getSharedPreferences("java21", MODE_PRIVATE);
		field.setTextColor(MyThemes.getColor(this));
		btnSubm.setTextColor(MyThemes.getColor(this));
		btnDate.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				dialog = onTimePicker();
				dialog.show();
			}
		});
		txtDate.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				dialog = onTimePicker();
				dialog.show();
			}
		});
		btnSubm.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				if (edtKey.getText().toString().trim().equals(""))
				{
					Toast.makeText(getApplicationContext(), "请输入注册码", Toast.LENGTH_LONG).show();
					return;
				}
				String rdate = txtDate.getText().toString();
				if (rdate.equals(""))
				{
					Toast.makeText(getApplicationContext(), "请先选择时间", Toast.LENGTH_LONG).show();
					return;
				}
				regist(rdate,edtKey.getText().toString().trim());
			}
		});
		back.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				finish();
			}
		});
	}
	
	public AlertDialog onTimePicker()
    {
		View view = ((LayoutInflater)getSystemService(LAYOUT_INFLATER_SERVICE)).inflate(R.layout.timepicker, null); 

		yearWheel = (WheelView)view.findViewById(R.id.wh_year);
		monthWheel = (WheelView)view.findViewById(R.id.wh_month);
		dayWheel = (WheelView)view.findViewById(R.id.wh_day);
		
		setTheme(android.R.style.Theme_DeviceDefault_Light_NoActionBar);

		yearWheel.setAdapter(new StrericWheelAdapter(years));
		yearWheel.setCurrentItem(mYear);
		yearWheel.setCyclic(false);
		yearWheel.setInterpolator(new AnticipateOvershootInterpolator());
		yearWheel.addChangingListener(new OnWheelChangedListener()
		{
			public void onChanged(WheelView v, int old, int ned)
			{
				mYear = ned;
				days = getDays(Integer.parseInt(yearWheel.getCurrentItemValue()), monthWheel.getCurrentItem());
				dayWheel.setAdapter(new StrericWheelAdapter(days));
				if (mDay >= days.length)
					dayWheel.setCurrentItem(0);
			}
		});

		monthWheel.setAdapter(new StrericWheelAdapter(months));
		monthWheel.setCurrentItem(mMonth);
		monthWheel.setCyclic(true);
		monthWheel.setInterpolator(new AnticipateOvershootInterpolator());
		monthWheel.addChangingListener(new OnWheelChangedListener()
		{
			public void onChanged(WheelView v, int old, int ned)
			{
				mMonth = ned;
				days = getDays(Integer.parseInt(yearWheel.getCurrentItemValue()),ned);
				dayWheel.setAdapter(new StrericWheelAdapter(days));
				if (mDay >= days.length)
					dayWheel.setCurrentItem(0);
			}
		});

		dayWheel.setAdapter(new StrericWheelAdapter(getDays(Integer.parseInt(yearWheel.getCurrentItemValue()),0)));
		dayWheel.setCurrentItem(mDay);
		dayWheel.setCyclic(true);
		dayWheel.setInterpolator(new AnticipateOvershootInterpolator());
		dayWheel.addChangingListener(new OnWheelChangedListener()
		{
			public void onChanged(WheelView v, int old, int ned)
			{
				mDay = ned;
			}
		});
		builder = new AlertDialog.Builder(this);  
		builder.setView(view);
		builder.setTitle("选择注册日期");  
		builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener()
		{
			@Override  
			public void onClick(DialogInterface dialog, int which)
			{
				txtDate.setText(yearWheel.getCurrentItemValue() + "-"
								+monthWheel.getCurrentItemValue() + "-"
								+dayWheel.getCurrentItemValue());
			}
		});
		return builder.create();
    }
	
	private int getYearsItem(String y)
	{
		for (int i=0;i<years.length;i++)
		{
			if (y.equals(years[i]))
				return i;
			else
				continue;
		}
		return 0;
	}
	
	private String[] getDays(int year, int month)
	{
		Calendar can = Calendar.getInstance();
		can.set(Calendar.YEAR, year);
		can.set(Calendar.MONTH, month);
		int max = can.getActualMaximum(Calendar.DAY_OF_MONTH);
		String[] day = new String[max];
		for (int i=0;i<max;i++)
		{
			if (i<9)
				day[i] = "0" + (i+1);
			else
				day[i] = ""+(i+1);
		}
		return day;
	}
	
	private void regist(String rdate, String key)
	{
		try
		{
			DecHelper dec = new DecHelper("java");
			String[] keys = key.split("-");
			String[] dates = rdate.split("-");
			if (keys.length == 4)
			{
				String password = dec.decrypt(keys[0]+keys[1]+keys[2]+keys[3]);
				if (password.indexOf(dates[1]+dates[2]) >= 0)
				{
					Toast.makeText(getApplicationContext(), "激活成功！", Toast.LENGTH_SHORT).show();
					SharedPreferences.Editor editor = spf.edit();
					editor.putBoolean("active", true);
					editor.putString("key", key);
					editor.putString("date", rdate);
					editor.putBoolean("pro", false);
					editor.commit();
					finish();
				}
				else
				{
					Toast.makeText(getApplicationContext(), "抱歉，选择的时间无效，请重新选择！", Toast.LENGTH_LONG).show();
				}
			}
			else
			{
				Toast.makeText(getApplicationContext(), "抱歉，注册码输入错误，请重新输入！", Toast.LENGTH_LONG).show();
				edtKey.setText("");
			}
		}
		catch (Exception e)
		{
			Toast.makeText(getApplicationContext(), "无效的注册码，请重新输入！", Toast.LENGTH_LONG).show();
			edtKey.setText("");
		}
	}
	
	@Override
	protected void onResume()
	{
		MyThemes.setThemeColor(this, title);
		super.onResume();
	}
}
