package com.vbea.java21;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.widget.Toast;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.RelativeLayout;
import android.util.DisplayMetrics;
import android.view.View;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.BitmapDrawable;

import com.ant.liao.GifView;
import com.ant.liao.GifView.GifImageType;
import com.tencent.stat.StatService;//腾讯云接入
import com.qq.e.ads.*;
import com.vbea.java21.classes.Common;
import com.vbea.java21.classes.MyImageView;
import com.vbea.java21.view.SnowFlack;
import com.vbea.java21.classes.CircleImageView;

public class Main extends Activity
{
	private long exitTime = 0;
	
	private boolean active;
	private SharedPreferences spt;
	//private Button btn_start, btn_apidoc, btn_help, btn_about;
	private RelativeLayout banner;
	private TextView txt_title;
	private boolean isActived = false;
	private boolean ispro = false;
	private Bundle bundle;
	private MyImageView miv_study, miv_video, miv_review, miv_test, miv_api, miv_books;
	private SnowFlack snowView;
	private ImageButton cir_about, cir_help, cir_setting, cir_more, cir_theme;
	private int[] resource,colorids;
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		StatService.trackCustomEvent(this, "onCreate", "");
		spt = getSharedPreferences("java21", Context.MODE_PRIVATE);
		banner = (RelativeLayout) findViewById(R.id.banner1);
		miv_study = (MyImageView) findViewById(R.id.miv_study);
		miv_video = (MyImageView) findViewById(R.id.miv_video);
		miv_review = (MyImageView) findViewById(R.id.miv_review);
		miv_test = (MyImageView) findViewById(R.id.miv_test);
		miv_api = (MyImageView) findViewById(R.id.miv_apis);
		miv_books = (MyImageView) findViewById(R.id.miv_setting);
		cir_about = (ImageButton) findViewById(R.id.cir_about);
		cir_help = (ImageButton) findViewById(R.id.cir_help);
		cir_more = (ImageButton) findViewById(R.id.cir_more);
		cir_theme = (ImageButton) findViewById(R.id.cir_theme);
		cir_setting = (ImageButton) findViewById(R.id.cir_setting);
		snowView = (SnowFlack) findViewById(R.id.snow_view);
		txt_title = (TextView) findViewById(R.id.txt_title);
		Common.GIF = spt.getBoolean("gif", true);
		Common.CHAPTER = spt.getInt("chapter", 0);
		Common.IS_ACTIVE = spt.getBoolean("skip", false);
		miv_study.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				startActvity(new Intent(Main.this, Chapter.class), bundle);
			}
		});
		
		miv_api.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				startActvity(new Intent(Main.this, ApiWord.class));
			}
		});
		cir_help.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				startActvity(new Intent(Main.this, Help.class), bundle);
			}
		});
		cir_about.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				startActvity(new Intent(Main.this, About.class), bundle);
			}
		});
		cir_theme.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				startActvity(new Intent(Main.this, Themes.class), bundle);
			}
		});
		cir_setting.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				startActvity(new Intent(Main.this, Setting.class), bundle);
			}
		});
		
		int width = getWindowManager().getDefaultDisplay().getWidth();
		int height = getWindowManager().getDefaultDisplay().getHeight();
		DisplayMetrics dis = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dis);
		float de = dis.density;
		snowView.setWH(width, height, de);
		if (Common.GIF)
			snowView.start();
		resource = new int[]{R.drawable.ui_shape, R.drawable.ui_item_0,
							R.drawable.ui_item_1, R.drawable.ui_item_2,
							R.drawable.ui_item_3, R.drawable.ui_item_4,
							R.drawable.ui_item_5, R.drawable.ui_item_6,
							R.drawable.ui_item_7, R.drawable.ui_item_8,
							R.drawable.ui_item_9
		};
		colorids = new int[]{R.color.title_w, R.color.blue_w,
							R.color.title1_w, R.color.title2_w,
							R.color.title4_w, R.color.title5_w,
							R.color.title6_w, R.color.title7_w,
							R.color.title8_w, R.color.title9_w,
							R.color.title11_w
		};
	}

	public void startText()
	{
		active = spt.getBoolean("active", false);
		ispro = spt.getBoolean("block", true);
		if (ispro) onBanner();
		else banner.setVisibility(View.GONE);
		isActived = !active;
		Drawable icon = getResources().getDrawable(R.drawable.ui_study);
		Bitmap bd = Bitmap.createBitmap(icon.getIntrinsicWidth(),icon.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
		bd.eraseColor(getResources().getColor(colorids[Common.APP_THEME_ID]));
		
		BitmapDrawable bdd = new BitmapDrawable(bd);
		miv_study.setImageDrawable(getActivityDraw(bdd, icon));
		miv_video.setImageDrawable(getActivityDraw(bdd, getResources().getDrawable(R.drawable.ui_video)));
		miv_review.setImageDrawable(getActivityDraw(bdd, getResources().getDrawable(R.drawable.ui_review)));
		miv_test.setImageDrawable(getActivityDraw(bdd, getResources().getDrawable(R.drawable.ui_test)));
		miv_api.setImageDrawable(getActivityDraw(bdd, getResources().getDrawable(R.drawable.ui_document)));
		miv_books.setImageDrawable(getActivityDraw(bdd, getResources().getDrawable(R.drawable.ui_books)));
		
		cir_about.setBackgroundResource(resource[Common.APP_THEME_ID]);
		cir_help.setBackground(getResources().getDrawable(resource[Common.APP_THEME_ID]));
		cir_setting.setBackground(getResources().getDrawable(resource[Common.APP_THEME_ID]));
		cir_more.setBackground(getResources().getDrawable(resource[Common.APP_THEME_ID]));
		cir_theme.setBackground(getResources().getDrawable(resource[Common.APP_THEME_ID]));
		txt_title.setBackgroundResource(colorids[Common.APP_THEME_ID]);
		
		if (!Common.GIF)
		{
			snowView.SNOW = Common.GIF;
			snowView.setVisibility(View.GONE);
		}
	}
	
	public void startActvity(Intent intent)
	{
		if (isActived)
			intent.setClass(Main.this, Chapter03.class);
		startActivity(intent);
	}

	public void startActvity(Intent intent, Bundle savedInstanceState)
	{
		startActivity(intent);
	}
	
	@Override
	public void onWindowFocusChanged(boolean hasFocus)
	{
		Common.TITLE_HEIGHT = txt_title.getHeight()-10;
		super.onWindowFocusChanged(hasFocus);
	}
	
	public LayerDrawable getActivityDraw(BitmapDrawable bdd, Drawable icon)
	{
		Drawable[] layers = { bdd, icon };
		return new LayerDrawable(layers);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		if(keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN)
		{
			if((System.currentTimeMillis() - exitTime) > 2000)
			{
				if (Common.CHAPTER != spt.getInt("chapter", Common.CHAPTER))
				{
					SharedPreferences.Editor edt = spt.edit();
					edt.putInt("chapter", Common.CHAPTER);
					if (edt.commit())
						Toast.makeText(Main.this,"再按一次退出程序",Toast.LENGTH_SHORT).show();
					exitTime = System.currentTimeMillis();
				}
				else
				{
					Toast.makeText(Main.this,"再按一次退出程序",Toast.LENGTH_SHORT).show();
					exitTime = System.currentTimeMillis();
				}
			}
			else
				onDestroyd();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
	/*public boolean isNet()
	{
		ConnectivityManager zdapp = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		if (zdapp == null)
		{
			return false;
		}
		else
		{
			NetworkInfo[] info = zdapp.getAllNetworkInfo();
			if (info != null)
			{
				for (int i=0; i<info.length; i++)
				{
					if (info[i].getState() == NetworkInfo.State.CONNECTED)
					{
						return true;
					}
				}
				//zdapp.getActiveNetworkInfo().isAvailable()
			}
		}
		return false;
	}*/
	protected void onBanner()
	{
		banner.setVisibility(View.VISIBLE);
		//AdView adv = new AdView(this, AdSize.BANNER, "1101326556", "9007479618592438842");
		AdView adv = new AdView(this, AdSize.BANNER, "1150078134", "9079537216925334074");
		banner.addView(adv);
		AdRequest adr = new AdRequest();
		adr.setRefresh(30);
		adv.setAdListener(new AdListener()
		{
			@Override
			public void onNoAd()
			{
				//Log.i("no ad cb:","no");
			}
			@Override
			public void onAdReceiv()
			{
					//Log.i("ad recv cb","revc");
			}
		});
		adv.fetchAd(adr);
	}
	
	@Override
	protected void onResume()
	{
		StatService.onResume(this);
		startText();
		super.onResume();
	}

	@Override
	protected void onPause()
	{
		super.onPause();
		StatService.onPause(this);
	}

	@Override
	protected void onDestroyd()
	{
		snowView.recly();
		//释放占用的内存资源
		finish();
		android.os.Process.killProcess(android.os.Process.myPid());
		super.onDestroy();
		//System.exit(0);
	}
}
