package com.vbea.java21;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.content.Context;
import android.content.SharedPreferences;
import android.app.AlertDialog.Builder;
import com.tencent.stat.StatService;
import android.widget.TextView;
import java.util.Timer;
import java.util.TimerTask;

import com.vbea.java21.classes.Common;
import com.vbea.java21.classes.ExceptionHandler;

public class MainActivity extends Activity
{
	private TextView retry;
	SharedPreferences spf;
	/**Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome);
		ExceptionHandler halder = ExceptionHandler.getInstance();
		halder.init(getApplicationContext());
		retry = (TextView) findViewById(R.id.text_retry);
		StatService.trackCustomEvent(this, "onCreate", "");
		spf = getSharedPreferences("java21", Context.MODE_PRIVATE);
		//boolean act = spf.getBoolean("isActive", false);
		new Thread()
		{
			public void run()
			{
				try
				{
					Message msg;
					for (int i = 0; i < 7; i++)
					{
						sleep(500);
						msg = new Message();
						msg.what = 1;
						msg.arg1 = i;
						handler.sendMessage(msg);
					}
					sleep(200);
					handler.sendEmptyMessage(2);
					//检查注册码
					Common.APP_THEME_ID = spf.getInt("theme", 0);
					Common.KEY key = Common.isActivity(spf.getString("key", ""), spf.getString("date",""));
					SharedPreferences.Editor editor = spf.edit();
					editor.putBoolean("active", key.active);
					if (!key.pro)
					{
						editor.putBoolean("pro", key.pro);
						editor.putBoolean("block", true);
					}
					editor.commit();
					sleep(200);
					handler.sendEmptyMessage(4);
				}
				catch(Exception e)
				{
			
				}
			}
		}.start();
	}
	
	Handler handler = new Handler()
	{
		public void handleMessage(Message msg)
		{
			switch (msg.what)
			{
				case 1:
					runText(msg.arg1);
					break;
				case 2:
					retry.setText("检查注册信息");
					break;
				case 3:
					retry.setText("检查注册-" + (msg.arg1==1?"已注册":"未注册"));
					break;
				case 4:
					retry.setText("正在载入");
					Intent intent=new Intent(MainActivity.this,Main.class);
					overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
					startActivity(intent);
					MainActivity.this.finish();
					break;
				case 5:
					//Toast.makeText(getApplicationContext(), msg.obj.toString(), Toast.LENGTH_SHORT).show();
					break;
			}
			super.handleMessage(msg);
		}
	};
	
	public void runText(int aime)
	{
		switch (aime)
		{
			case 0:
				retry.setText("加载中"+" "+" "+" ");
				break;
			case 1:
			case 4:
				retry.setText("加载中."+" "+" ");
				break;
			case 2:
			case 5:
				retry.setText("加载中.."+" ");
				break;
			case 3:
			case 6:
				retry.setText("加载中...");
				break;
		}
	}
	
	@Override
	protected void onResume()
	{
		MyThemes.setThemeMain(this);
		super.onResume();
	}
}
