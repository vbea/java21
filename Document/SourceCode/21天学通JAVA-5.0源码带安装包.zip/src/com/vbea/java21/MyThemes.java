package com.vbea.java21;

import android.app.Activity;
import android.os.Build;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.content.Context;
import android.content.SharedPreferences;

import com.vbea.java21.classes.Common;

public class MyThemes
{
	static final int[] colorids = {
		R.color.title,
		R.color.blue,
		R.color.title1,
		R.color.title2,
		R.color.title4,
		R.color.title5,
		R.color.title6,
		R.color.title7,
		R.color.title8,
		R.color.title9,
		R.color.title11
	};
	
	public static void setThemeColor(Activity content, RelativeLayout title)
	{
		checkThemeId(content);
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT)
		{
			//状态栏
			content.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			//导航栏
			//content.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
			SystemBarTintManager tintManager = new SystemBarTintManager(content);
			tintManager.setStatusBarTintEnabled(true);
			//此处可以重新指定状态栏颜色
			//tintManager.setStatusBarTintResource(resid);
			tintManager.setStatusBarTintResource(colorids[Common.APP_THEME_ID]);
			title.setBackgroundResource(colorids[Common.APP_THEME_ID]);
		}
	}
	
	public static void setThemeMain(Activity content)
	{
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT)
		{
			//状态栏
			content.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			//导航栏
			//content.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
			SystemBarTintManager tintManager = new SystemBarTintManager(content);
			tintManager.setStatusBarTintEnabled(true);
			//此处可以重新指定状态栏颜色
			//tintManager.setStatusBarTintResource(resid);
			tintManager.setStatusBarTintResource(R.color.white);
		}
	}
	
	public static int getColorId()
	{
		if (Common.APP_THEME_ID < colorids.length)
			return colorids[Common.APP_THEME_ID];
		else
			return colorids[0];
	}
	
	public static int getColor(Context context)
	{
		return context.getResources().getColor(Common.APP_THEME_ID < colorids.length?colorids[Common.APP_THEME_ID]:colorids[0]);
	}
	
	public static void checkThemeId(Activity content)
	{
		if (Common.APP_THEME_ID == -1)
		{
			SharedPreferences spf = content.getSharedPreferences("java21", Context.MODE_PRIVATE);
			Common.APP_THEME_ID = spf.getInt("theme", 0);
		}
		if (Common.APP_THEME_ID >= colorids.length)
		{
			Common.APP_THEME_ID = 0;
		}
	}
}
