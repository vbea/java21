package com.vbea.java21;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import android.view.View.*;
import android.view.*;
import android.content.*;

public class NotNetError extends Activity
{
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.warning);
		
		Button set = (Button) findViewById(R.id.btn_Wquit);
		set.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				Intent intent = new Intent();
				intent.setAction(android.provider.Settings.ACTION_SETTINGS);
				startActivity(intent);
				NotNetError.this.finish();
				//onDestroy()
				return;
			}
		});
	}
	/*@Override
	protected void onDestroy()
	{
		//释放占用的内存资源
		finish();
		android.os.Process.killProcess(android.os.Process.myPid());
		super.onDestroy();
		System.exit(0);
	}*/
}
