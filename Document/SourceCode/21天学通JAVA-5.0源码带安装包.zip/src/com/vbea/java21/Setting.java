package com.vbea.java21;

import android.app.Activity;
import android.os.Bundle;
import android.widget.RelativeLayout;
import android.widget.LinearLayout;
import android.widget.Button; 
import android.widget.ImageButton;
import android.widget.Toast;
import android.view.View;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;

import com.vbea.java21.classes.SlidButton;
import com.vbea.java21.classes.*;

public class Setting extends Activity
{
	private RelativeLayout title;
	private SlidButton sldGift,sldSkip,sldAdver;
	private SharedPreferences spf;
	private boolean isPro = false;
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.settings);
		Button btnSetheme = (Button) findViewById(R.id.btn_setheme);
		Button btnGift = (Button) findViewById(R.id.btn_setGift);
		Button btnPast = (Button) findViewById(R.id.btn_setPast);
		Button btnSkip = (Button) findViewById(R.id.btn_setSkip);
		Button btnAdver = (Button) findViewById(R.id.btn_setBanner);
		Button btnScore = (Button) findViewById(R.id.btn_setScore);
		Button btnJoin = (Button) findViewById(R.id.btn_setJoin);
		Button btnHelp = (Button) findViewById(R.id.btn_setHelp);
		Button btnAbout = (Button) findViewById(R.id.btn_setAbout);
		ImageButton back = (ImageButton) findViewById(R.id.btn_back);
		sldAdver = (SlidButton) findViewById(R.id.slid_adver);
		title = (RelativeLayout) findViewById(R.id.bg_title);
		sldGift = (SlidButton) findViewById(R.id.slid_gift);
		sldSkip = (SlidButton) findViewById(R.id.slid_skip);
		spf = getSharedPreferences("java21", MODE_PRIVATE);
		sldGift.setEnabled(false);
		sldSkip.setEnabled(false);
		sldAdver.setEnabled(false);
		
		btnSetheme.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				startActivity(new Intent(Setting.this, Themes.class));
			}
		});
		btnGift.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				sldGift.toggle();
				if (Common.GIF = sldGift.getChecked())
					Toast.makeText(getApplicationContext(), "已打开动画效果，退出后再次运行时生效。", Toast.LENGTH_SHORT).show();
			}
		});
		btnSkip.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				if (Common.APP_THEME || sldSkip.getChecked())
				{
					sldSkip.toggle();
					Common.IS_ACTIVE = sldSkip.getChecked();
				}
				else
					Toast.makeText(getApplicationContext(),"该功能需要注册后才能使用", Toast.LENGTH_SHORT).show();
			}
		});
		btnPast.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				startActivity(new Intent(Setting.this, Machine.class));
			}
		});
		btnAdver.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				if (isPro || sldAdver.getChecked())
					sldAdver.toggle();
				else
					Toast.makeText(getApplicationContext(),"该功能需要注册专业版才能使用", Toast.LENGTH_SHORT).show();
			}
		});
		btnScore.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				try
				{
					Uri uri = Uri.parse("market://details?id="+getPackageName());
					Intent intent = new Intent(Intent.ACTION_VIEW,uri);
					intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					startActivity(intent);
				}
				catch (Exception e)
				{
					Toast.makeText(getApplicationContext(), "未检测到应用商店", Toast.LENGTH_SHORT).show();
				}
			}
		});
		btnJoin.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				startActivity(new Intent(Setting.this, VbeStudio.class));
			}
		});
		btnHelp.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				startActivity(new Intent(Setting.this, Help.class));
			}
		});
		btnAbout.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				startActivity(new Intent(Setting.this, About.class));
			}
		});
		back.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				finish();
			}
		});
		sldGift.setOnChangedListener(new SlidButton.OnChangedListener()
		{
			@Override
			public void OnChanged(SlidButton witch, boolean checkState)
			{
				Common.GIF = checkState;
			}
		});
	}
	
	private void init()
	{
		isPro = spf.getBoolean("pro", false);
		sldGift.setChecked(spf.getBoolean("gif",true));
		sldSkip.setChecked(spf.getBoolean("skip", false));
		sldAdver.setChecked(!spf.getBoolean("block", true));
	}
	
	@Override
	protected void onResume()
	{
		MyThemes.setThemeColor(this, title);
		init();
		super.onResume();
	}
	
	@Override
	protected void onDestroy()
	{
		SharedPreferences.Editor edt = spf.edit();
		edt = spf.edit();
		edt.putBoolean("gif",sldGift.getChecked());
		edt.putBoolean("skip",sldSkip.getChecked());
		edt.putBoolean("block", sldAdver.getChecked(0));
		edt.commit();
		super.onDestroy();
	}
}
