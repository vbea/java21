package com.vbea.java21;

import java.util.List;
import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.AdapterView;
import android.content.SharedPreferences;

import com.vbea.java21.classes.ThemeItem;
import com.vbea.java21.classes.ThemeAdapter;
import com.vbea.java21.classes.Common;

public class Themes extends Activity
{
	private List<ThemeItem> mItem = new ArrayList<ThemeItem>();
	private RelativeLayout title;
	private ThemeAdapter adapter;
	private SharedPreferences spf;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		setTheme(android.R.style.Theme_DeviceDefault_Light_NoActionBar);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.theme);
		
		ListView mListView = (ListView) findViewById(R.id.listTheme);
		title = (RelativeLayout) findViewById(R.id.bg_title);
		ImageButton back = (ImageButton) findViewById(R.id.btn_back);
		spf = getSharedPreferences("java21", MODE_PRIVATE);
		getData();
		adapter = new ThemeAdapter(this, mItem);
		mListView.setAdapter(adapter);
		
		mListView.setOnItemClickListener(new AdapterView.OnItemClickListener()
		{
			@Override
			public void onItemClick(AdapterView<?> p1, View p2, int p3, long p4)
			{
				if (Common.APP_THEME_ID == p3)
					return;
				Common.APP_THEME_ID = p3;
				MyThemes.setThemeColor(Themes.this, title);
				adapter.notifyDataSetChanged();
			}
		});
		
		mListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener()
		{
			@Override
			public boolean onItemLongClick(AdapterView<?> p1, View p2, int p3, long p4)
			{
				return Common.APP_THEME_ID != p3;
			}
		});
		
		back.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				onDestroy();
				finish();
			}
		});
	}
	
	private void getData()
	{
		int[] colorids = {
			R.color.title,
			R.color.blue,
			R.color.title1,
			R.color.title2,
			R.color.title4,
			R.color.title5,
			R.color.title6,
			R.color.title7,
			R.color.title8,
			R.color.title9,
			R.color.title11
		};
		String[] colornames = {
			"默认","天蓝色","湖水蓝","森林绿",
			"草苗绿","妖艳橘","咸蛋黄","香槟金",
			"少女粉","西瓜红","葡萄紫"
		};
		for (int i=0;i<colorids.length;i++)
		{
			mItem.add(new ThemeItem(getResources().getColor(colorids[i]), colornames[i]));
		}
	}

	@Override
	protected void onResume()
	{
		MyThemes.setThemeColor(this, title);
		super.onResume();
	}

	@Override
	protected void onDestroy()
	{
		SharedPreferences.Editor edt = spf.edit();
		edt.putInt("theme", Common.APP_THEME_ID);
		edt.commit();
		super.onDestroy();
	}
	
}
