package com.vbea.java21.classes;

public class Common
{
	public static int APP_THEME_ID = -1;
	public static int TITLE_HEIGHT = 0;
	public static boolean GIF = true;
	public static boolean APP_THEME = false;
	public static boolean IS_ACTIVE = false;
	public static int CHAPTER=0;
	public static int TRAINING=0;
	
	public static KEY isActivity(String key, String date)
	{
		KEY k = new KEY();
		try
		{
			DecHelper dec = new DecHelper("java");
			String[] keys = key.split("-");
			String[] dates = date.split("-");
			if (keys.length == 4 && dates.length == 3)
			{
				String password = dec.decrypt(keys[0]+keys[1]+keys[2]+keys[3]);
				k.active = (password.indexOf(dates[1]+dates[2]) >= 0);
				APP_THEME = k.active;
				if (password.toLowerCase().endsWith("p"))
					k.pro = true;
			}
		}
		catch (Exception e)
		{
			k.active = false;
		}
		return k;
	}
	
	public static class KEY
	{
		public boolean active = false;
		public boolean pro = false;
	}
}
