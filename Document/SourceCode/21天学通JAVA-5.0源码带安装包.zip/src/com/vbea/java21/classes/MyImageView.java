package com.vbea.java21.classes;

import android.content.Context;
import android.graphics.Camera;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PaintFlagsDrawFilter;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.ImageView;
import android.widget.ImageButton;
import android.widget.Toast;

public class MyImageView extends ImageView {

	private boolean onAnimation = true;
	private int rotateDegree = 10;

	private boolean isFirst = true;
	private float minScale = 0.95f;
	private int vWidth;
	private int vHeight;
	private boolean isFinish = true,isActionMove=false,isScale=false;
	private Camera camera;
	private Context mContext;
	boolean XbigY = false;
	float RolateX = 0;
	float RolateY = 0;

	OnMyViewClick onclick=null;
	// 计算点击的次数
	private int counts = 0;
	// 第一次点击的时间 long型
	private long firstClick = 0;
	// 最后一次点击的时间
	private long custClick = 0;
	
	public MyImageView(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		camera = new Camera();
		mContext =context;
	}

	public MyImageView(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		camera = new Camera();
		mContext =context;
	}

	public void SetAnimationOnOff(boolean oo) {
		onAnimation = oo;
	}
	public void setOnClickIntent(OnMyViewClick onclick){
		this.onclick=onclick;
	}
	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		if (isFirst) {
			isFirst = false;
			init();
		}
		canvas.setDrawFilter(new PaintFlagsDrawFilter(0, Paint.ANTI_ALIAS_FLAG
				| Paint.FILTER_BITMAP_FLAG));
	}

	public void init() {
		vWidth = getWidth() - getPaddingLeft() - getPaddingRight();
		vHeight = getHeight() - getPaddingTop() - getPaddingBottom();
		//Drawable drawable = getDrawable();
		//BitmapDrawable bd = (BitmapDrawable) drawable;
		//bd.setAntiAlias(true);
	}

	@Override
	public void setImageDrawable(LayerDrawable drawable)
	{
		BitmapDrawable bd = (BitmapDrawable) drawable.getDrawable(0);
		bd.setAntiAlias(true);
		BitmapDrawable bd1 = (BitmapDrawable) drawable.getDrawable(1);
		bd1.setAntiAlias(true);
		super.setImageDrawable(drawable);
	}
	
	

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		super.onTouchEvent(event);
		if (!onAnimation)
			return true;

		
		switch (event.getAction() & MotionEvent.ACTION_MASK) {
		case MotionEvent.ACTION_DOWN:
		// 如果第二次点击 距离第一次点击时间过长 那么将第二次点击看为第一次点击
			if (firstClick != 0 && System.currentTimeMillis() - firstClick > 500)
				counts = 0;
			counts++;
			if (counts == 1)
			{
				firstClick = System.currentTimeMillis();
			} 
			else if (counts >= 2)
			{
				// 两次点击小于500ms 也就是连续点击
				if (custClick - firstClick < 500)
				{
					custClick = firstClick;
					firstClick = System.currentTimeMillis();
				}
			}
			//custClick = System.currentTimeMillis();
			if (counts == 5)
				Toast.makeText(mContext, "(>﹏<)好痛，不要再戳我了", Toast.LENGTH_SHORT).show();
			else if (counts == 10)
				Toast.makeText(mContext, "(┯_┯)还戳，疼死我了", Toast.LENGTH_SHORT).show();
			else if (counts == 15)
				Toast.makeText(mContext, "妈妈，有人一直戳我 呜呜(┯_┯)", Toast.LENGTH_SHORT).show();
			else if (counts == 25)
				Toast.makeText(mContext, "(┯_┯)一直戳我，不跟你玩了！", Toast.LENGTH_SHORT).show();
			else if (counts == 30 || counts == 40)
				Toast.makeText(mContext, "亲，不要再戳了，这个功能伦家还没做出来呢", Toast.LENGTH_SHORT).show();
			if (counts != 1)
				break;
			float X = event.getX();
			float Y = event.getY();
			RolateX = vWidth / 2 - X;
			RolateY = vHeight / 2 - Y;
			XbigY = Math.abs(RolateX) > Math.abs(RolateY) ? true : false;

			isScale = X > vWidth / 3 && X < vWidth * 2 / 3 && Y > vHeight / 3&& Y < vHeight * 2 / 3;
			isActionMove=false;
			
			if (isScale) {
				handler.sendEmptyMessage(1);
			} else {
				rolateHandler.sendEmptyMessage(1);
			}
			break;
		case MotionEvent.ACTION_MOVE:
			float x=event.getX();float y=event.getY();
			if(x>vWidth || y>vHeight || x<0 || y<0){
				isActionMove=true;
			}else{
				isActionMove=false;
			}
			
			break;
		case MotionEvent.ACTION_UP:
			if (isScale) {
				handler.sendEmptyMessage(6);
			} else {
				rolateHandler.sendEmptyMessage(6);
			}
			break;
		}
		return true;
	}
	public interface OnMyViewClick {
		public void onClick();
	}
	private Handler rolateHandler = new Handler() {
		private Matrix matrix = new Matrix();
		private float count = 0;

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			matrix.set(getImageMatrix());
			switch (msg.what) {
			case 1:
				count = 0;
				BeginRolate(matrix, (XbigY ? count : 0), (XbigY ? 0 : count));
				rolateHandler.sendEmptyMessage(2);
				break;
			case 2:
				BeginRolate(matrix, (XbigY ? count : 0), (XbigY ? 0 : count));
				if (count < getDegree()) {
					rolateHandler.sendEmptyMessage(2);
				} else {
					isFinish = true;
				}
				count++;
				count++;
				break;
			case 3:
				BeginRolate(matrix, (XbigY ? count : 0), (XbigY ? 0 : count));
				if (count > 0) {
					rolateHandler.sendEmptyMessage(3);
				} else {
					isFinish = true;
					if(!isActionMove&&onclick!=null){
						onclick.onClick();
					}
				}
				count--;
				count--;
				break;
			case 6:
				count = getDegree();
				BeginRolate(matrix, (XbigY ? count : 0), (XbigY ? 0 : count));
				rolateHandler.sendEmptyMessage(3);
				break;
			}
		}
	};

	private synchronized void BeginRolate(Matrix matrix, float rolateX,
			float rolateY) {
		// Bitmap bm = getImageBitmap();
		int scaleX = (int) (vWidth * 0.5f);
		int scaleY = (int) (vHeight * 0.5f);
		camera.save();
		camera.rotateX(RolateY > 0 ? rolateY : -rolateY);
		camera.rotateY(RolateX < 0 ? rolateX : -rolateX);
		camera.getMatrix(matrix);
		camera.restore();
		// 控制中心点
		if (RolateX > 0 && rolateX != 0) {
			matrix.preTranslate(-vWidth, -scaleY);
			matrix.postTranslate(vWidth, scaleY);
		} else if (RolateY > 0 && rolateY != 0) {
			matrix.preTranslate(-scaleX, -vHeight);
			matrix.postTranslate(scaleX, vHeight);
		} else if (RolateX < 0 && rolateX != 0) {
			matrix.preTranslate(-0, -scaleY);
			matrix.postTranslate(0, scaleY);
		} else if (RolateY < 0 && rolateY != 0) {
			matrix.preTranslate(-scaleX, -0);
			matrix.postTranslate(scaleX, 0);
		}
		setImageMatrix(matrix);
	}

	private Handler handler = new Handler() {
		private Matrix matrix = new Matrix();
		private float s;
		int count = 0;

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			matrix.set(getImageMatrix());
			switch (msg.what) {
			case 1:
				if (!isFinish) {
					return;
				} else {
					isFinish = false;
					count = 0;
					s = (float) Math.sqrt(Math.sqrt(minScale));
					BeginScale(matrix, s);
					handler.sendEmptyMessage(2);
				}
				break;
			case 2:
				BeginScale(matrix, s);
				if (count < 4) {
					handler.sendEmptyMessage(2);
				} else {
					isFinish = true;
					if(!isActionMove&&onclick!=null){
						onclick.onClick();
					}
				}
				count++;
				break;
			case 6:
				/*else if (counts > 2)
				{
					s = (float) Math.sqrt(Math.sqrt(1.0f / minScale));
					BeginScale(matrix, s);
					isFinish = true;
					break;
				}*/
				if (!isFinish) {
					handler.sendEmptyMessage(7);
				} else {
					isFinish = false;
					count = 0;
					s = (float) Math.sqrt(Math.sqrt(1.0f / minScale));
					BeginScale(matrix, s);
					handler.sendEmptyMessage(2);
				}
				break;
				case 7:
					if (System.currentTimeMillis() - firstClick < 500)
					{
						handler.sendEmptyMessageDelayed(7, 100);
						break;
					}
					else
					{
						counts = 0;
					}
					break;
			}
		}
	};

	private synchronized void BeginScale(Matrix matrix, float scale)
	{
		if (counts >= 2)
		{
			handler.sendEmptyMessage(6);
			//setImageMatrix(matrix);
			return;
		}
		int scaleX = (int) (vWidth * 0.5f);
		int scaleY = (int) (vHeight * 0.5f);
		matrix.postScale(scale, scale, scaleX, scaleY);
		setImageMatrix(matrix);
	}

	public int getDegree() {
		return rotateDegree;
	}

	public void setDegree(int degree) {
		rotateDegree = degree;
	}

	public float getScale() {
		return minScale;
	}

	public void setScale(float scale) {
		minScale = scale;
	}
}
