package com.vbea.java21.classes;

public class ThemeItem
{
	public int rid;
	public String name;
	
	public ThemeItem(int id, String n)
	{
		rid = id;
		name = n;
	}
}
