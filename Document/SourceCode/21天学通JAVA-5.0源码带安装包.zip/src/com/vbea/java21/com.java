package com.vbea.java21;

public class com
{
}