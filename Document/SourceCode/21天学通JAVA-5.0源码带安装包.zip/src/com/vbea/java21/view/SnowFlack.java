package com.vbea.java21.view;

import java.util.Random;

import android.os.Handler;
import android.os.Message;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.util.AttributeSet;
import android.view.View;

import com.vbea.java21.R;

public class SnowFlack extends View
{
	Bitmap mFlowers = null;
	MyFlower flowers [] = new MyFlower[60];//50片雪花
	private Integer[] offsetX ;
	private Integer[] offsetY ;
	Random rad = new Random();
	Matrix m = new Matrix();
	Paint p = new Paint();
	int mW = 480;
	int mH = 800;
	float de = 0f;
	public boolean SNOW = true;
	
	public SnowFlack(Context context)
	{
		super(context);
	}
	
	public SnowFlack(Context context, AttributeSet attr)
	{
		super(context, attr);
	}
	
	public SnowFlack(Context context, AttributeSet attr, int def)
	{
		super(context, attr, def);
	}
	
	public void setWH(int pW, int pH, float de)
	{
		this.mW = pW;
		this.mH = pH;
		this.de = de;
		//System.out.println(de ----> + de);
		offsetX = new Integer[]{ (int)(2*de), (int)(-2*de), (int)(-1*de), 0, (int)(1*de), (int)(2*de), (int)(1*de) };
		offsetY = new Integer[]{ (int)(3*de), (int)(5*de), (int)(5*de), (int)(3*de), (int)(4*de)};
		loadFlower();
		addRect();
	}
	
	@Override
	protected void onDraw(Canvas canvas)
	{
		super.onDraw(canvas);
		for (int i = 0; i < flowers.length; i++)
		{
			MyFlower rect = flowers[i];
			int t = rect.t;
			t--;
			if (t <= 0)
			{
				rect.y += rect.g;canvas.save();
				m.reset();
				m.setScale(rect.s, rect.s);
				canvas.setMatrix(m);
				p.setAlpha(rect.a);
				canvas.drawBitmap(mFlowers, rect.x, rect.y, p);
				canvas.restore();
			}
			rect.t = t;
			if (rect.y >= mH)
				rect.init();
			if (rect.x >= mW || rect.x < - 20)
				rect.init();
			flowers[i] = rect;
		}
	}
	
	public void loadFlower()
	{
		Resources r = this.getContext().getResources();
		mFlowers = ((BitmapDrawable)r.getDrawable(R.drawable.snows)).getBitmap();
	}
	
	public void recly()
	{
		SNOW = false;
		if (mFlowers != null && !mFlowers.isRecycled())
		{
			mFlowers.recycle();
		}
	}
	
	public void addRect()
	{
		for (int i = 0; i < flowers.length; i++)
		{
			flowers[i] = new MyFlower();
		}
	}
	
	public void inva(){
		invalidate();
	}
	
	public synchronized void start()
	{
		if (!thread.isAlive())
		{
			thread.start();
		}
	}
	
	public void pause()
	{
		try
		{
			thread.wait();
		}
		catch (Exception e)
		{
			
		}
	}
	
	class MyFlower
	{
		int x;
		int y;
		float s;
		int a;
		int t;
		int g;
		
		public void init()
		{
			float aa = rad.nextFloat();
			this.x = rad.nextInt(mW - 80) + 80;
			this.y = 0;
			if (aa >= 1)
				this.s = 1.1f;
			else if (aa <= 0.2) 
				this.s = 0.4f;
			else
				this.s = aa;
			this.a = rad.nextInt(155) + 100;
			this.t = rad.nextInt(105) + 1;
			this.g = offsetY[rad.nextInt(4)];
		}
		
		public MyFlower()
		{
			super();
			init();
		}
	}
	
	Thread thread = new Thread(new Runnable()
	{
		public void run()
		{
			try
			{
				Thread.sleep(5000);
				while (SNOW)
				{
					Thread.sleep(50);
					mHandler.sendEmptyMessage(1);
				}
			}
			catch (Exception e)
			{
				SNOW = false;
			}
		}
	});
	
	public Handler mHandler = new Handler()
	{
		@Override
		public void dispatchMessage(Message msg)
		{
			invalidate();
		}
	};
}
